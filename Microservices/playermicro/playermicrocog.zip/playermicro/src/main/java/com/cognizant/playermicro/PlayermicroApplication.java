package com.cognizant.playermicro;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PlayermicroApplication {

	public static void main(String[] args) {
		SpringApplication.run(PlayermicroApplication.class, args);
	}

}
