package com.cognizant.playermicro.service;

import java.util.Optional;
import java.util.List;

import com.cognizant.playermicro.exception.PlayerAdditionException;
import com.cognizant.playermicro.exception.PlayerNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cognizant.playermicro.entity.Player;
import com.cognizant.playermicro.repository.PlayerRepository;

//import antlr.collections.List;
import java.util.*;
@Service
public class PlayerService {
	
	@Autowired
	private PlayerRepository playerRepository ;
	
	public Player addPlayer(Long playerId, String playerName,  int age, long contactNumber, String email,
			String gender,String sportsName) {


		if(playerId == null || playerName == null || age<=0 || contactNumber <= 100000000 || email == null || gender == null || sportsName == null)
			throw new PlayerAdditionException(" Fields Cannot be empty!!");


		playerRepository.findPlayerByPlayerId(playerId)
				.ifPresent(u -> {
					throw new PlayerAdditionException("Player with id: "+playerId+" already exists!");
				});

		Player player=new Player( playerId, playerName, age, contactNumber,  email,
			 gender,sportsName);
		return playerRepository.save(player);
		
	}


	public void deletePlayer(Long playerId) {
		Optional<Player> player= playerRepository.findPlayerByPlayerId(playerId);
		player.ifPresent(value -> playerRepository.delete(value));
        player.orElseThrow(() -> new PlayerNotFoundException("Event with Id "+playerId+" is not found!"));
	}
	
	
	  public List<Player> findAllPlayer() 
	  { 
		  return playerRepository.findAll();
	  }
	 

}
