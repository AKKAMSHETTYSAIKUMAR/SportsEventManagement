package com.cognizant.playermicro;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PlayermicroApplicationTests {

	@Test
	void contextLoads() {
	}

}
